import { useState } from 'react';
import { useRuleStore } from '../../store';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Textarea } from '../../components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '../../components/ui/dialog';
import { Badge } from '../../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../components/ui/tabs';
import { Checkbox } from '../../components/ui/checkbox';
import {
  BookOpen,
  Plus,
  Search,
  Edit,
  Trash2,
  CheckCircle,
  XCircle,
  Clock,
  GitMerge,
  ArrowUpRight,
} from 'lucide-react';
import { toast } from 'sonner';

const ruleCategories = [
  'Privacy & Security',
  'Appointments',
  'Prescriptions',
  'Lab Results',
  'Billing',
  'General',
];

const KnowledgeBase = () => {
  const { rules, addRule, updateRule, deleteRule, mergeRules } = useRuleStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isMergeDialogOpen, setIsMergeDialogOpen] = useState(false);
  const [selectedRules, setSelectedRules] = useState([]);
  const [editingRule, setEditingRule] = useState(null);

  const [ruleForm, setRuleForm] = useState({
    title: '',
    description: '',
    category: 'General',
  });

  const [mergeForm, setMergeForm] = useState({
    title: '',
    description: '',
    category: 'General',
  });

  const filteredRules = rules.filter((rule) => {
    const matchesSearch =
      rule.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rule.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSearch;
  });

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-amber-600" />;
      case 'declined':
        return <XCircle className="w-4 h-4 text-red-600" />;
    }
  };

  const getStatusBadge = (status) => {
    const styles = {
      approved: 'bg-green-100 text-green-700 dark:bg-green-500/20 dark:text-green-400',
      pending: 'bg-amber-100 text-amber-700 dark:bg-amber-500/20 dark:text-amber-400',
      declined: 'bg-red-100 text-red-700 dark:bg-red-500/20 dark:text-red-400',
    };
    return (
      <Badge className={styles[status]}>
        <span className="flex items-center gap-1 capitalize">
          {getStatusIcon(status)}
          {status}
        </span>
      </Badge>
    );
  };

  const handleAddRule = () => {
    if (!ruleForm.title.trim() || !ruleForm.description.trim()) {
      toast.error('Please fill in all fields');
      return;
    }

    addRule({
      title: ruleForm.title,
      description: ruleForm.description,
      category: ruleForm.category,
      status: 'pending',
      createdBy: '1',
    });

    toast.success('Rule added successfully!');
    setIsAddDialogOpen(false);
    setRuleForm({ title: '', description: '', category: 'General' });
  };

  const handleEditRule = () => {
    if (!editingRule) return;

    updateRule(editingRule.id, {
      title: ruleForm.title,
      description: ruleForm.description,
      category: ruleForm.category,
    });

    toast.success('Rule updated successfully!');
    setIsEditDialogOpen(false);
    setEditingRule(null);
    setRuleForm({ title: '', description: '', category: 'General' });
  };

  const handleStatusChange = (ruleId, status) => {
    updateRule(ruleId, { status });
    toast.success(`Rule ${status} successfully!`);
  };

  const handleDeleteRule = (ruleId) => {
    if (confirm('Are you sure you want to delete this rule?')) {
      deleteRule(ruleId);
      toast.success('Rule deleted successfully!');
    }
  };

  const openEditDialog = (rule) => {
    setEditingRule(rule);
    setRuleForm({
      title: rule.title,
      description: rule.description,
      category: rule.category,
    });
    setIsEditDialogOpen(true);
  };

  const toggleRuleSelection = (ruleId) => {
    setSelectedRules((prev) =>
      prev.includes(ruleId) ? prev.filter((id) => id !== ruleId) : [...prev, ruleId]
    );
  };

  const openMergeDialog = () => {
    if (selectedRules.length < 2) {
      toast.error('Please select at least 2 rules to merge');
      return;
    }
    
    const firstRule = rules.find((r) => r.id === selectedRules[0]);
    if (firstRule) {
      setMergeForm({
        title: firstRule.title,
        description: firstRule.description,
        category: firstRule.category,
      });
    }
    setIsMergeDialogOpen(true);
  };

  const handleMergeRules = () => {
    if (!mergeForm.title.trim() || !mergeForm.description.trim()) {
      toast.error('Please fill in all fields');
      return;
    }

    mergeRules(selectedRules, {
      title: mergeForm.title,
      description: mergeForm.description,
      category: mergeForm.category,
      status: 'approved',
      createdBy: '1',
    });

    toast.success('Rules merged successfully!');
    setIsMergeDialogOpen(false);
    setSelectedRules([]);
    setMergeForm({ title: '', description: '', category: 'General' });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-[10px] font-bold uppercase tracking-widest">
            <BookOpen className="w-3.5 h-3.5" />
            Governance Engine
          </div>
          <h1 className="text-2xl font-black tracking-tight">Knowledge Base</h1>
          <p className="text-muted-foreground text-sm">Define and manage AI clinical reasoning protocols</p>
        </div>
        <div className="flex gap-2">
          {selectedRules.length > 1 && (
            <Button 
              variant="outline" 
              onClick={() => setIsMergeDialogOpen(true)}
              className="h-10 px-5 rounded-xl font-bold border-primary/20 text-primary hover:bg-primary/5 text-xs"
            >
              <GitMerge className="w-4 h-4 mr-2" />
              Merge ({selectedRules.length})
            </Button>
          )}
          <Button 
            onClick={() => setIsAddDialogOpen(true)}
            className="bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20 h-10 px-5 rounded-xl font-bold group text-xs"
          >
            <Plus className="w-4 h-4 mr-2 transition-transform group-hover:rotate-90" />
            Create Rule
          </Button>
        </div>
      </div>

      {/* Search & Tabs */}
      <Tabs defaultValue="all" className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <TabsList className="bg-muted/50 p-1 rounded-xl h-12 border border-border/50 backdrop-blur-sm">
            <TabsTrigger value="all" className="rounded-lg px-6 font-bold uppercase tracking-widest text-[10px]">All Rules</TabsTrigger>
            <TabsTrigger value="approved" className="rounded-lg px-6 font-bold uppercase tracking-widest text-[10px]">Approved</TabsTrigger>
            <TabsTrigger value="pending" className="rounded-lg px-6 font-bold uppercase tracking-widest text-[10px]">Pending</TabsTrigger>
          </TabsList>
          
          <div className="relative group flex-1 md:max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
            <Input
              placeholder="Search by title, content, or category..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-11 h-12 bg-background/50 border-border/50 focus:border-primary/50 focus:ring-primary/20 rounded-xl transition-all text-sm"
            />
          </div>
        </div>

        {['all', 'pending', 'approved'].map((tabValue) => (
          <TabsContent key={tabValue} value={tabValue} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
              {filteredRules
                .filter((rule) => tabValue === 'all' || rule.status === tabValue)
                .length > 0 ? (
                filteredRules
                  .filter((rule) => tabValue === 'all' || rule.status === tabValue)
                  .map((rule) => (
                    <Card 
                      key={rule.id} 
                      className="group border-0 shadow-lg shadow-black/5 dark:shadow-white/5 rounded-2xl overflow-hidden bg-card/50 backdrop-blur-sm border-white/20 dark:border-white/5 hover:shadow-xl transition-all duration-500 hover:-translate-y-0.5"
                    >
                      <CardHeader className="p-6 pb-3">
                        <div className="flex justify-between items-start mb-5">
                          <div className="flex items-center gap-2.5">
                            <Checkbox 
                              checked={selectedRules.includes(rule.id)}
                              onCheckedChange={() => toggleRuleSelection(rule.id)}
                              className="w-4 h-4 rounded-md border-primary/20 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                            />
                            {getStatusBadge(rule.status)}
                          </div>
                          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => openEditDialog(rule)}
                              className="w-8 h-8 rounded-lg hover:bg-primary/10 hover:text-primary"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => handleDeleteRule(rule.id)}
                              className="w-8 h-8 rounded-lg hover:bg-destructive/10 hover:text-destructive"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </div>
                        <CardTitle className="text-lg font-bold tracking-tight group-hover:text-primary transition-colors leading-tight">
                          {rule.title}
                        </CardTitle>
                        <div className="mt-2">
                          <Badge variant="outline" className="text-[9px] font-black uppercase tracking-widest border-primary/20 text-primary/70 px-2 py-0">
                            {rule.category}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="p-6 pt-0">
                        <p className="text-muted-foreground text-xs leading-relaxed line-clamp-3 font-medium mb-5">
                          {rule.description}
                        </p>
                        <div className="flex items-center justify-between pt-5 border-t border-border/40">
                          <div className="text-[9px] font-black uppercase tracking-[0.15em] text-muted-foreground/40">
                            Updated {new Date(rule.updatedAt).toLocaleDateString()}
                          </div>
                          <Button variant="link" className="p-0 h-auto font-bold text-primary text-[11px] group/link">
                            View Protocol
                            <ArrowUpRight className="w-3 h-3 ml-1 transition-transform group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <div className="col-span-full py-24 text-center">
                    <div className="w-16 h-16 bg-muted/50 rounded-full flex items-center justify-center mx-auto mb-5">
                      <BookOpen className="w-8 h-8 text-muted-foreground/30" />
                    </div>
                    <h3 className="text-xl font-bold text-foreground mb-1">No rules found</h3>
                    <p className="text-xs text-muted-foreground max-w-xs mx-auto mb-6 font-medium leading-relaxed">
                      Start by defining your first reasoning rule to help the AI understand your medical protocols.
                    </p>
                    <Button 
                      onClick={() => setIsAddDialogOpen(true)}
                      className="rounded-xl h-11 px-6 font-bold shadow-lg shadow-primary/20 text-sm"
                    >
                      Define First Rule
                    </Button>
                  </div>
                )}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {/* Add Rule Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-lg dark:bg-slate-800">
          <DialogHeader>
            <DialogTitle className="text-gray-800 dark:text-white">Add New Rule</DialogTitle>
            <DialogDescription className="dark:text-gray-400">
              Create a new rule for the knowledge base.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Rule Title</label>
              <Input
                value={ruleForm.title}
                onChange={(e) => setRuleForm((prev) => ({ ...prev, title: e.target.value }))}
                placeholder="Enter rule title"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Category</label>
              <Select
                value={ruleForm.category}
                onValueChange={(value) => setRuleForm((prev) => ({ ...prev, category: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {ruleCategories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Description</label>
              <Textarea
                value={ruleForm.description}
                onChange={(e) => setRuleForm((prev) => ({ ...prev, description: e.target.value }))}
                placeholder="Enter rule description"
                rows={4}
              />
            </div>
            <Button onClick={handleAddRule} className="w-full bg-teal-500 hover:bg-teal-600">
              Add Rule
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-lg dark:bg-slate-800">
          <DialogHeader>
            <DialogTitle className="text-gray-800 dark:text-white">Edit Rule</DialogTitle>
            <DialogDescription className="dark:text-gray-400">Update the rule details below.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Rule Title</label>
              <Input
                value={ruleForm.title}
                onChange={(e) => setRuleForm((prev) => ({ ...prev, title: e.target.value }))}
                placeholder="Enter rule title"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Category</label>
              <Select
                value={ruleForm.category}
                onValueChange={(value) => setRuleForm((prev) => ({ ...prev, category: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {ruleCategories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Description</label>
              <Textarea
                value={ruleForm.description}
                onChange={(e) => setRuleForm((prev) => ({ ...prev, description: e.target.value }))}
                placeholder="Enter rule description"
                rows={4}
              />
            </div>
            <Button onClick={handleEditRule} className="w-full bg-teal-500 hover:bg-teal-600">
              Update Rule
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Merge Dialog */}
      <Dialog open={isMergeDialogOpen} onOpenChange={setIsMergeDialogOpen}>
        <DialogContent className="sm:max-w-lg dark:bg-slate-800">
          <DialogHeader>
            <DialogTitle className="text-gray-800 dark:text-white">Merge Rules</DialogTitle>
            <DialogDescription className="dark:text-gray-400">
              Combine {selectedRules.length} selected rules into one.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="p-3 bg-gray-50 dark:bg-slate-700 rounded-lg">
              <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Selected Rules:</p>
              <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                {selectedRules.map((ruleId) => {
                  const rule = rules.find((r) => r.id === ruleId);
                  return rule ? <li key={ruleId}>• {rule.title}</li> : null;
                })}
              </ul>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Merged Rule Title</label>
              <Input
                value={mergeForm.title}
                onChange={(e) => setMergeForm((prev) => ({ ...prev, title: e.target.value }))}
                placeholder="Enter merged rule title"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Category</label>
              <Select
                value={mergeForm.category}
                onValueChange={(value) => setMergeForm((prev) => ({ ...prev, category: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {ruleCategories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Merged Description</label>
              <Textarea
                value={mergeForm.description}
                onChange={(e) => setMergeForm((prev) => ({ ...prev, description: e.target.value }))}
                placeholder="Enter merged description"
                rows={4}
              />
            </div>
            <Button onClick={handleMergeRules} className="w-full bg-orange-500 hover:bg-orange-600">
              <GitMerge className="w-4 h-4 mr-2" />
              Merge Rules
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default KnowledgeBase;
